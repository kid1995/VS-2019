import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.scene.shape.Box;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Client extends Application {
	private String input;
	private static final String QUIT = "Q";
	private static final String GET = "G";
	private static final String SEND = "S";

	public void setInput(String input) {
		this.input = input;
	}

	public String getInput() {
		return this.input;
	}

	@Override
	public void start(Stage stage) throws Exception {
		// Getting the registry
		Registry registry = LocateRegistry.getRegistry(null);
		// Looking up the registry for the remote object
		MessageService stub = (MessageService) registry.lookup("MessageService");
		// Calling the remote method using the obtained object


		Text text = new Text("Please enter your ClientID");
		text.setX(50);
		text.setY(50);
		text.setFont(Font.font("Verdana", FontWeight.BOLD, 15));

		Text infoText = new Text("");
		infoText.setX(50);
		infoText.setY(200);
		infoText.setFill(Color.GREEN);
		infoText.setFont(Font.font("Verdana",15));

		// Creating a text filed
		TextField textField = new TextField();

		// Setting the position of the text field
		textField.setLayoutX(50);
		textField.setLayoutY(100);

		TextField msgField = new TextField();
		msgField.setLayoutX(50);
		msgField.setLayoutY(160);

		textField.setOnAction(new EventHandler<ActionEvent>() {
			String msg = "";
			String clientID = "";

			@Override
			public void handle(ActionEvent event) {
				text.setText("Please enter your command");
				if (event.getEventType().equals(ActionEvent.ACTION)) {
					if (clientID.equals("")) {
						clientID = textField.getText();
						textField.clear();
					} else {
						switch (textField.getText()) {
						case QUIT:
							textField.clear();
							try {
								Platform.exit();
								System.exit(0);
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							break;
						case GET:
							textField.clear();
							try {
								msg = stub.nextMessage(clientID);
							} catch (RemoteException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							if (msg != null) {
								infoText.setText("Received message: " + msg);
							} else {
								infoText.setText("No new message !!!");
							}
							text.setText("Please enter your command!");
							break;
						case SEND:
							textField.clear();
							text.setText("Please enter your message in the textfield below!");
							msgField.setOnAction(new EventHandler<ActionEvent>() {
								@Override
								public void handle(ActionEvent event) {
									text.setText("Please enter your message2");
									if (event.getEventType().equals(ActionEvent.ACTION)) {
										try {
											msg = msgField.getText();
											System.out.println(msg);
											stub.newMessage(clientID, msg);
											msgField.clear();
										} catch (RemoteException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
										infoText.setText("Message : \"" + msg + "\" sent!");
										text.setText("Please enter your command!");
									}
								}

							});
							break;
						}
					}
				}
			}
		});

		// Creating a Group object
		Group root = new Group(textField, text, msgField, infoText);

		// Creating a scene object
		Scene scene = new Scene(root, 800, 300);
		stage.setTitle("Test");
		stage.setScene(scene);
		stage.show();
	}

	public static void main(String[] args) {
		launch();
	}

}
