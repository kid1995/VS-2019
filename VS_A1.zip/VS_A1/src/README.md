# VS-2019
VS 2019 Project

#########
#Install#
#########
Open Command Line (Terminal) on current folder.

check if javac was included in System Variable Path: 

	javac -version

using this link to add, if it was not in System Variable Path

https://javatutorial.net/set-java-home-windows-10

If it was there, then run these commands:

	javac *.java


#####
#Run#
#####
Start Java RMI App:

	start rmiregistry

Start Server Side:

	java Server

Start Client Side:

	java Client



!!! Using another Terminal for Client, and turn off all App before reopen, else a error wil happen